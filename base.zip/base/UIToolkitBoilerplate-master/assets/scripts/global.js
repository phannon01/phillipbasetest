// Allstate global namespace
$.als = $.als || {};

// Utilities
$.als.utilities = $.als.utilities || {};

// Plugins
$.als.plugins = $.als.plugins || {};
