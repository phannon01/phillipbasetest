# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]

### HIG Update
#### v0.9.21

- Added 'txt--left' modifier class example on [alignment](http://ux.allstate.com/ux/allstateuitoolkit/#/components/alignment) page.
- Add explicit line height on all buttons to maintain consistency between button types.
- Modified default positioning of [tooltips](http://ux.allstate.com/ux/allstateuitoolkit/#/components/tooltips) to display above text, rather than below, and allowed for this default behavior to be modified.

#### v0.9.2

- Created new jQuery boilerplate and rewrote all javascript dependent components (dialogs/modals, tooltips, timepicker, etc...) using this new plugin pattern.
- [Dialogs/modals](http://ux.allstate.com/ux/allstateuitoolkit/#/components/dialog) and [tooltips](http://ux.allstate.com/ux/allstateuitoolkit/#/components/tooltips) require new javascript file references.
- [Dialogs/modals](http://ux.allstate.com/ux/allstateuitoolkit/#/components/dialog) now have optional parameters to control overlay functionality, applying active CSS classes to the modal, and callbacks after showing/hiding modals.
- Created new [timepicker](http://ux.allstate.com/ux/allstateuitoolkit/#/components/timepicker) component.
- Replaced core.js with utilities.js.
- Numerous bug fixes.

#### v.0.9.1

- Updated UI styles of buttons, button groups, hints, headings, links, labels, input fields, calendar (date picker), massage, and dropdown menus to reflect new visual branding.
- Removed top margin from the first item in a .vList as to remove any unwanted spacing.
- Updated .oList to use count properties to allow for proper text wrapping.
- Updated spacing within the .affix pattern.
- Reduced the width of contextual modals from 45% to 40%.
- Updated dropdown menus to no longer require inline SVG icons and instead use new icons as background data URIs.

### Initial Commit
#### v.0.91

- First version taken directly from contents of UIEngineering/Distribution/UI-Toolkit-Archive/v0.9.1.zip
- Added index.html
- Removed pdfs folder
- Removed theme-1 folder from images folder
- Added themes/app folder to images
- Added themes/app folder to styles
- Edited app.less to reference themes/app
- Added _theme.less, _variables.less and theme.css 



