module.exports = function(grunt) {
    /* Configuring Grunt task options
       ========================================================================== */
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        // Process LESS files
        less: {
            development: {
                options: {
                    paths: ["assets/styles/"],
                    compress: true,
                    yuicompress: true,
                    optimization: 2
                },
                files: {
                    "assets/styles/app.css": "assets/styles/app.less"
                }
            }
        }
    });
    /* Loading in Grunt tasks
       ========================================================================== */
    grunt.loadNpmTasks('grunt-contrib-less');

    /* Registered Grunt tasks
       ========================================================================== */
    grunt.registerTask('default', ['less:development']);
};