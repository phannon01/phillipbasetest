var express = require("express");
var mysql = require("mysql");;
var connection = mysql.createConnection({
  host: 'eu-cdbr-azure-west-d.cloudapp.net',
  user: 'ba044e7743685b',
  password: 'ad192169',
  database : 'anibodydatabase'
})
var app = express();

connection.connect(function(err){
  if(!err) {
    console.log("database is connected");
  }else{
    console.log("Error connecting database");
  }
});

app.get("/",function(req,res){
  connection.query('SELECT * from markers', function(err, rows, fields) {
connection.end();
  if (!err)
    console.log('The solution is: ', rows);
  else
    console.log('Error while performing Query.');
  });
});

app.listen(9000);
