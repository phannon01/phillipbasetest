var express = require('express');
var router = express.Router();

/* GET updating_information */
router.get('/', function(req, res, next) {
  res.render('edit_dealing_with_a_suicide');
});

module.exports = router;
