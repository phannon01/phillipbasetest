var express = require('express');
var router = express.Router();

/* GET helpful_information page. */
router.get('/', function(req, res, next) {
  res.render('helpful_information');
});

module.exports = router;
