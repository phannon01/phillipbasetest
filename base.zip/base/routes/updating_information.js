var express = require('express');
var router = express.Router();

/* GET updating_information */
router.get('/', function(req, res, next) {
  res.render('updating_information');
});

module.exports = router;
