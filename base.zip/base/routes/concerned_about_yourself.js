var express = require('express');
var router = express.Router();

/* GET concerned_about_yourself page. */
router.get('/', function(req, res, next) {
  res.render('concerned_about_yourself');
});

module.exports = router;
