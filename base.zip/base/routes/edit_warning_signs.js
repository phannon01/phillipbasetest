var express = require('express');
var router = express.Router();

/* GET updating_information */
router.get('/', function(req, res, next) {
  res.render('edit_warning_signs');
});

module.exports = router;
