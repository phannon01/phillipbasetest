var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var connections = require('./databse_connection');
var service_name1;

/* GET wellbeing_scale page. */
router.get('/', function(req, res, next) {

  connections.query('SELECT * FROM markers', function(error, rows, fields){
    if(error){
      console.log('error viewing data');
    }else{
      console.log('successful connection');
      map=rows[0].service_name;
    }


  res.render('wellbeing_scale', {service_name1:map});
});
});

module.exports = router;
