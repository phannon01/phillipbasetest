var express = require('express');
var router = express.Router();

/* GET wellbeing_scale_results page. */
router.get('/', function(req, res, next) {
  res.render('wellbeing_scale_results');
});

module.exports = router;
