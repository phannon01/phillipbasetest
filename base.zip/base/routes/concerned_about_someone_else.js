var express = require('express');
var router = express.Router();

/* GET concerned_about_someone_else page. */
router.get('/', function(req, res, next) {
  res.render('concerned_about_someone_else');
});

module.exports = router;
