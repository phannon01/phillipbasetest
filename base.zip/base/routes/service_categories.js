var express = require('express');
var router = express.Router();

/* GET service_categories page. */
router.get('/', function(req, res, next) {
  res.render('service_categories');
});

module.exports = router;
